﻿/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'font', 'az', {
	fontSize: {
		label: 'Şrift ölçüsü',
		voiceLabel: 'Şrift ölçüsü',
		panelTitle: 'Şrift ölçüsü'
	},
	label: 'Şrift',
	panelTitle: 'Şrift',
	voiceLabel: 'Şrift'
} );
